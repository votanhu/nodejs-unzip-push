'use strict';

angular.module('mean').config(['$stateProvider',
    function($stateProvider) {
        $stateProvider.state('zippackage example page', {
            url: '/zippackage/example',
            templateUrl: 'zippackage/views/index.html'
        });
    }
]);
