'use strict';

angular.module('mean').controller('ZippackageController', ['$scope', 'Global',
    function($scope, Global, Zippackage) {
        $scope.global = Global;
        $scope.zippackage = {
            name: 'zippackage'
        };
    }
]);
